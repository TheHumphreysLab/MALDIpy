Updates in MALDIpy v0.1.3; compared to v0.1.1:

New functions: MALDIpy.featureplot.plot2features; MALDIpy.featureplot.plot2features_subset
