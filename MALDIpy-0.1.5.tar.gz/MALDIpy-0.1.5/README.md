Updates in MALDIpy v0.1.5; compared to v0.1.3:

New functions #1: MALDIpy.projection.add_coords;
#Extract X/Y coordinates from the adata.obs.index and added to obs

New functions #2: MALDIpy.featureplot.project_cluster_in_groups
#Plot any clusters in a group of samples (x/y coordinates should be in adata.obs for this function)