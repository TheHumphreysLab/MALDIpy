Updates in MALDIpy v0.1.1; compared to v0.0.2:

(1) New function: MALDIpy.projection.umap_projection_subset

(2) New function: MALDIpy.featureplot, which includes four subfunctions (plot1feature,plot1feature_subset,twofeatureplot,twofeatureplot_subset)